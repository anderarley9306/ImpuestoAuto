package ImpuestosCarros;

public class Modelo {
    private String marca;
    private int modelo;
    private int cilindraje;
    private double avaluo;
    private boolean publico;

    public Modelo(String marca, int modelo, int cilindraje, double avaluo, boolean publico) {
        this.marca = marca;
        this.modelo = modelo;
        this.cilindraje = cilindraje;
        this.avaluo = avaluo;
        this.publico = publico;
    }

    public double calcularImpuesto() {
        double porcentaje;

        // reglas reglas para descuento por cilindraje
        if (cilindraje <= 1000) {
            porcentaje = 0.15; 
        } else if (cilindraje <= 2000) {
            porcentaje = 0.20; 
        } else {
            porcentaje = 0.25; 
        }

        double impuesto = avaluo * porcentaje;

        // Descuento si es un auto de uso publico
        if (publico) {
            impuesto = impuesto * 0.70; 
        }

        return impuesto;
    }
}
