package ImpuestosCarros;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;

public class Vista extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtModelo;
	private JTextField txtCilindraje;
	private JTextField txtAvaluo;
	private JComboBox<String> cboxMarca;
    private JCheckBox checkPublic;
    private JButton btnCalcular;
    private JButton btnLimpiar;
    private JTextArea textValorImpuesto;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Vista frame = new Vista();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public Vista() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 557, 438);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);		
		setResizable(false);
		
		JLabel lbltitulo = new JLabel("Calculadora Impuestos");
		lbltitulo.setBounds(186, 11, 131, 34);
		contentPane.add(lbltitulo);
		
		JLabel lblMarca = new JLabel("Marca");
		lblMarca.setBounds(121, 72, 46, 14);
		contentPane.add(lblMarca);
		
		JLabel lblModelo = new JLabel("Modelo");
		lblModelo.setBounds(121, 105, 46, 14);
		contentPane.add(lblModelo);
		
		JLabel lblCilindraje = new JLabel("Cilindraje");
		lblCilindraje.setBounds(121, 143, 86, 14);
		contentPane.add(lblCilindraje);
		
		JLabel lblAvaluo = new JLabel("Avalúo Comercial");
		lblAvaluo.setBounds(121, 179, 196, 14);
		contentPane.add(lblAvaluo);
		
		JLabel lblpublico = new JLabel("Marque si es de uso público");
		lblpublico.setBounds(121, 213, 196, 14);
		contentPane.add(lblpublico);
		
		txtModelo = new JTextField();
		txtModelo.setBounds(318, 102, 86, 20);
		contentPane.add(txtModelo);
		txtModelo.setColumns(10);
		
		txtCilindraje = new JTextField();
		txtCilindraje.setBounds(318, 140, 86, 20);
		contentPane.add(txtCilindraje);
		txtCilindraje.setColumns(10);
		
		txtAvaluo = new JTextField();
		txtAvaluo.setBounds(318, 176, 86, 20);
		contentPane.add(txtAvaluo);
		txtAvaluo.setColumns(10);
		
		cboxMarca = new JComboBox();
		cboxMarca.setModel(new DefaultComboBoxModel<>(new String[] {"", "Renault", "Kia", "Toyota", "Chevrolet", "Mazda", "Nissan", "Suzuki", 
				"Hyundai", "Volkswagen", "BYD", "Ford", "Foton", "Mercedes-Benz", "BMW", 
				"Citroën", "JAC", "Subaru", "MG", "JMC (JMEV)", "Peugeot", "Honda", "Volvo", 
				"Dongfeng", "Changan-Deepal", "Cupra", "FAW-Bestune", "Chery", "Fiat",
				"GWM (Great Wall Motor)", "RAM", "Jeep", "Audi", "Mitsubishi"}));
		cboxMarca.setBounds(318, 68, 86, 22);
		contentPane.add(cboxMarca);
		
		checkPublic = new JCheckBox("");
		checkPublic.setBounds(318, 213, 97, 23);
		contentPane.add(checkPublic);
		
		btnCalcular = new JButton("Calcular");
		btnCalcular.setBounds(106, 253, 89, 23);
		contentPane.add(btnCalcular);
		
		btnLimpiar = new JButton("Limpiar");
		btnLimpiar.setBounds(349, 253, 89, 23);
		contentPane.add(btnLimpiar);
		
		textValorImpuesto = new JTextArea();
		textValorImpuesto.setBounds(139, 294, 265, 94);
		contentPane.add(textValorImpuesto);

	}
	
	  public JTextField getTxtModelo() {
	        return txtModelo;
	    }

	    public JTextField getTxtCilindraje() {
	        return txtCilindraje;
	    }

	    public JTextField getTxtAvaluo() {
	        return txtAvaluo;
	    }

	    public JComboBox<String> getCboxMarca() {
	        return cboxMarca;
	    }

	    public JCheckBox getCheckPublic() {
	        return checkPublic;
	    }

	    public JButton getBtnCalcular() {
	        return btnCalcular;
	    }

	    public JButton getBtnLimpiar() {
	        return btnLimpiar;
	    }

	    public JTextArea getTextValorImpuesto() {
	        return textValorImpuesto;
	    }
	}
	



