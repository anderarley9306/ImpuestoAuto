package ImpuestosCarros;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controlador {
    private Vista vista;

    public Controlador(Vista vista) {
        this.vista = vista;
        initControl();
    }

    private void initControl() {
        vista.getBtnCalcular().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calcularImpuesto();
            }
        });
        
        

        vista.getBtnLimpiar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        });
    }

    private void calcularImpuesto() {
        try {
            
            String marca = (String) vista.getCboxMarca().getSelectedItem();
            int modelo = Integer.parseInt(vista.getTxtModelo().getText());
            int cilindraje = Integer.parseInt(vista.getTxtCilindraje().getText());
            double avaluo = Double.parseDouble(vista.getTxtAvaluo().getText());
            boolean publico = vista.getCheckPublic().isSelected();

            
            Modelo vehiculo = new Modelo(marca, modelo, cilindraje, avaluo, publico);
            double impuesto = vehiculo.calcularImpuesto();

            //
            vista.getTextValorImpuesto().setText(
                "Marca: " + marca +
                "\nModelo: " + modelo +
                "\nCilindraje: " + cilindraje +
                "\nAvalúo: $" + String.format("%,.2f", avaluo) +
                
                "\n Impuesto a pagar: $" + String.format("%,.2f", impuesto)
            );

        } catch (Exception ex) {
            vista.getTextValorImpuesto().setText("⚠ Error en los datos ingresados.\nVerifica los campos.");
        }
    }

    private void limpiarCampos() {
        vista.getTxtModelo().setText("");
        vista.getTxtCilindraje().setText("");
        vista.getTxtAvaluo().setText("");
        vista.getCboxMarca().setSelectedIndex(0);
        vista.getCheckPublic().setSelected(false);
        vista.getTextValorImpuesto().setText("");
    }
}
