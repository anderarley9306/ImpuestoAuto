package ImpuestosCarros;

public class Main {
    public static void main(String[] args) {
        Vista vista = new Vista();
        vista.setVisible(true);   
        new Controlador(vista);   
    }
}

